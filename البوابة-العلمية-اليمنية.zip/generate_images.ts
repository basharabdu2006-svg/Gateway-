import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

async function generateScientificImages() {
  const prompts = [
    "A subtle, high-tech scientific research background with abstract DNA and molecular structures, soft lighting, professional dark green (#0d3b36) and gold (#c5a059) tones, 400x400",
    "A professional academic background representing elite scientists, featuring a modern laboratory or library with soft focus, dark green (#0d3b36) and gold (#c5a059) accents, 400x400",
    "A wide scientific banner showing futuristic technology and innovation, clean white and dark green (#0d3b36) aesthetic with gold highlights, 1200x300"
  ];

  const results = [];
  for (const prompt of prompts) {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [{ text: prompt }],
      },
    });

    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        results.push(`data:image/png;base64,${part.inlineData.data}`);
      }
    }
  }
  return results;
}

// Since I can't run this script and get the output back to my thought process easily 
// without a tool that returns stdout, I'll use the generateContent tool directly in my next turn
// if I were a human. But as an agent, I can just call the tool.
