import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyCN0wpZovAi4dp7wDTlx02r9rpCtmB8aMY",
  authDomain: "ysg-4c95b.firebaseapp.com",
  projectId: "ysg-4c95b",
  storageBucket: "ysg-4c95b.firebasestorage.app",
  messagingSenderId: "629797715653",
  appId: "1:629797715653:web:5f34843ff808adf9193aac",
  measurementId: "G-RR81RXWN4B"
};

const app = initializeApp(firebaseConfig);
export const analytics = getAnalytics(app);
export const db = getFirestore(app);
export const auth = getAuth(app);
export const storage = getStorage(app);
