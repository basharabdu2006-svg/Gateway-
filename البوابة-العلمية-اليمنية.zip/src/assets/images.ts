// This file will store the generated image base64 strings for the dashboard.
export const DASHBOARD_IMAGES = {
  TOP_RESEARCH: "https://picsum.photos/seed/research/400/400?blur=5",
  ELITE_RESEARCHERS: "https://picsum.photos/seed/academic/400/400?blur=5",
  MAIN_BANNER: "https://picsum.photos/seed/science/1200/300?blur=2"
};
