/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import { Search, Atom, MessageCircle, Share2, LogIn, User, TrendingUp, Calendar, Award, ArrowRight, ArrowLeft, LogOut, Sprout, PenTool, Star, Zap, Crown, Bell, Trash2, BookOpen, Home, Users, UserPlus, Camera } from 'lucide-react';
import React, { useState, useEffect, ChangeEvent } from 'react';
import { motion } from 'motion/react';
import { auth, db, storage } from './firebase';
import { collection, addDoc, query, where, onSnapshot, deleteDoc, doc, getDocs, setDoc, getDoc, serverTimestamp, orderBy, or } from 'firebase/firestore';
import { signInWithEmailAndPassword, createUserWithEmailAndPassword, onAuthStateChanged, signOut, signInWithPopup, GoogleAuthProvider, updateProfile } from 'firebase/auth';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { DASHBOARD_IMAGES } from './assets/images';

// ... (rest of the file)

const mockPosts = [
  { id: 1, author: 'د. أحمد علي', content: 'اكتشاف جديد في مجال الطاقة المتجددة في اليمن.', date: 'منذ ساعتين', atoms: 45 },
  { id: 2, author: 'سارة محمد', content: 'تأثير التغير المناخي على الزراعة في وادي حضرموت.', date: 'منذ ٥ ساعات', atoms: 88 },
];

const BADGE_CONFIG: Record<string, { icon: any, color: string, bg: string }> = {
  'باحث مبتدئ': { icon: Sprout, color: 'text-gray-500', bg: 'bg-gray-100 border border-gray-200' },
  'باحث واعد': { icon: Sprout, color: 'text-blue-600', bg: 'bg-blue-50 border border-blue-100' },
  'باحث نشط': { icon: PenTool, color: 'text-primary', bg: 'bg-primary/5 border border-primary/10' },
  'باحث متمكن': { icon: Award, color: 'text-teal-600', bg: 'bg-teal-50 border border-teal-100' },
  'نجم البحث': { icon: Star, color: 'text-orange-500', bg: 'bg-orange-50 border border-orange-100' },
  'عالم مشارك': { icon: Atom, color: 'text-purple-600', bg: 'bg-purple-50 border border-purple-100' },
  'عالم خبير': { icon: Atom, color: 'text-indigo-600', bg: 'bg-indigo-50 border border-indigo-100' },
  'عالم متميز': { icon: Crown, color: 'text-rose-600', bg: 'bg-rose-50 border border-rose-100' },
  'رائد علمي': { icon: Crown, color: 'text-gold', bg: 'bg-gold/10 border border-gold/20' },
  'أسطورة العلوم': { icon: Crown, color: 'text-yellow-600', bg: 'bg-yellow-100 border border-yellow-300 shadow-sm' },
};

function getBadgeForAtoms(atoms: number): string {
  if (atoms >= 1000) return 'أسطورة العلوم';
  if (atoms >= 500) return 'رائد علمي';
  if (atoms >= 250) return 'عالم متميز';
  if (atoms >= 100) return 'عالم خبير';
  if (atoms >= 50) return 'عالم مشارك';
  if (atoms >= 25) return 'نجم البحث';
  if (atoms >= 10) return 'باحث متمكن';
  if (atoms >= 5) return 'باحث نشط';
  if (atoms >= 1) return 'باحث واعد';
  return 'باحث مبتدئ';
}

const mockResearchers = [
  { id: 1, name: 'د. خالد عمر', atoms: { daily: 45, weekly: 320, monthly: 1200 }, badges: [getBadgeForAtoms(1200)] },
  { id: 2, name: 'د. فاطمة حسن', atoms: { daily: 60, weekly: 280, monthly: 950 }, badges: [getBadgeForAtoms(950)] },
  { id: 3, name: 'د. علي سعيد', atoms: { daily: 20, weekly: 150, monthly: 800 }, badges: [getBadgeForAtoms(800)] },
  { id: 4, name: 'د. محمد صالح', atoms: { daily: 80, weekly: 400, monthly: 750 }, badges: [getBadgeForAtoms(750)] },
  { id: 5, name: 'د. سارة أحمد', atoms: { daily: 10, weekly: 90, monthly: 600 }, badges: [getBadgeForAtoms(600)] },
];

function LoginPage({ onBack }: { onBack: () => void }) {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState('');

  const handleAuth = async () => {
    setError('');
    try {
      if (isLogin) {
        await signInWithEmailAndPassword(auth, email, password);
      } else {
        await createUserWithEmailAndPassword(auth, email, password);
      }
      // onAuthStateChanged in App will handle the state update and redirect
    } catch (err: any) {
      let errorMessage = 'حدث خطأ. يرجى المحاولة مرة أخرى.';
      if (err.code === 'auth/invalid-credential' || err.code === 'auth/user-not-found' || err.code === 'auth/wrong-password') {
        errorMessage = 'البريد الإلكتروني أو كلمة المرور غير صحيحة. يرجى التأكد أو إنشاء حساب جديد أولاً.';
      } else if (err.code === 'auth/email-already-in-use') {
        errorMessage = 'هذا البريد الإلكتروني مسجل بالفعل. يرجى تسجيل الدخول.';
      } else if (err.code === 'auth/weak-password') {
        errorMessage = 'كلمة المرور ضعيفة جداً. يجب أن تكون 6 أحرف على الأقل.';
      } else if (err.code === 'auth/invalid-email') {
        errorMessage = 'صيغة البريد الإلكتروني غير صحيحة.';
      }
      setError(errorMessage);
    }
  };

  const handleGoogleAuth = async () => {
    setError('');
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
    } catch (err: any) {
      let errorMessage = 'حدث خطأ أثناء تسجيل الدخول عبر جوجل.';
      if (err.code === 'auth/popup-closed-by-user') {
        errorMessage = 'تم إلغاء عملية تسجيل الدخول.';
      } else if (err.code === 'auth/account-exists-with-different-credential') {
        errorMessage = 'هذا البريد الإلكتروني مسجل مسبقاً بطريقة دخول مختلفة (مثل البريد وكلمة المرور). يرجى تسجيل الدخول بالطريقة الأصلية.';
      } else if (err.code === 'auth/popup-blocked') {
        errorMessage = 'تم حظر النافذة المنبثقة. يرجى السماح بالنوافذ المنبثقة لهذا الموقع.';
      }
      setError(errorMessage);
    }
  };

  return (
    <div dir="rtl" className="min-h-screen flex items-center justify-center bg-gray-50 p-4 font-sans">
      <div className="bg-white p-6 md:p-8 rounded-3xl shadow-sm border border-gray-100 w-full max-w-md text-center">
        <div className="h-12 w-12 md:h-16 md:w-16 bg-primary rounded-full flex items-center justify-center text-gold font-bold text-xl md:text-2xl mx-auto mb-6">YSP</div>
        <h2 className="text-xl md:text-2xl font-black text-primary mb-6">{isLogin ? 'تسجيل الدخول' : 'إنشاء حساب جديد'}</h2>
        
        {error && <p className="text-red-500 mb-4 text-sm">{error}</p>}

        {!isLogin && (
          <div className="flex gap-4 mb-4">
            <input type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="الاسم الكامل" className="w-full bg-gray-100 rounded-full py-2 px-4 md:py-3 md:px-6 outline-none focus:ring-2 focus:ring-gold" />
          </div>
        )}
        
        <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="البريد الإلكتروني" className="w-full bg-gray-100 rounded-full py-2 px-4 md:py-3 md:px-6 mb-4 outline-none focus:ring-2 focus:ring-gold" />
        <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="كلمة المرور (٦ أحرف على الأقل)" className="w-full bg-gray-100 rounded-full py-2 px-4 md:py-3 md:px-6 mb-6 outline-none focus:ring-2 focus:ring-gold" />
        
        <button onClick={handleAuth} className="w-full bg-primary text-white py-2 md:py-3 rounded-full font-bold mb-4 hover:bg-primary/90 transition-colors">{isLogin ? 'دخول' : 'إنشاء حساب'}</button>
        
        <div className="relative mb-4">
          <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-gray-200"></div></div>
          <div className="relative flex justify-center text-xs uppercase"><span className="bg-white px-2 text-gray-400">أو</span></div>
        </div>
        
        <button onClick={handleGoogleAuth} className="w-full bg-white border border-gray-200 text-gray-700 py-2 md:py-3 rounded-full font-bold mb-6 hover:bg-gray-50 transition-colors flex items-center justify-center gap-2">
          <img src="https://www.google.com/favicon.ico" alt="Google" className="w-4 h-4" />
          {isLogin ? 'تسجيل الدخول عبر جوجل' : 'إنشاء حساب عبر جوجل'}
        </button>

        <button onClick={() => setIsLogin(!isLogin)} className="text-primary font-bold mb-6 block w-full text-sm">{isLogin ? 'ليس لديك حساب؟ سجل الآن' : 'لديك حساب بالفعل؟ سجل دخولك'}</button>
        <button onClick={onBack} className="text-gray-500 font-bold flex items-center justify-center gap-2 mx-auto text-sm">
          <ArrowRight className="w-4 h-4" />
          العودة للرئيسية
        </button>
      </div>
    </div>
  );
}

function EventsPage({ onBack, events, user }: { onBack: () => void, events: any[], user: any }) {
  const [showAddEvent, setShowAddEvent] = useState(false);
  const [title, setTitle] = useState('');
  const [date, setDate] = useState('');
  const [location, setLocation] = useState('');
  const [registeredEvents, setRegisteredEvents] = useState<string[]>([]);

  useEffect(() => {
    if (!user) return;
    const fetchRegistrations = async () => {
      const q = query(collection(db, 'eventRegistrations'), where('userId', '==', user.uid));
      const snapshot = await getDocs(q);
      setRegisteredEvents(snapshot.docs.map(doc => doc.data().eventId));
    };
    fetchRegistrations();
  }, [user]);

  const handleAddEvent = async () => {
    if (!title || !date || !location) return;
    try {
      await addDoc(collection(db, 'events'), {
        title,
        date,
        location,
        createdAt: serverTimestamp(),
        authorId: user?.uid
      });
      setShowAddEvent(false);
      setTitle('');
      setDate('');
      setLocation('');
    } catch (e) {
      console.error("Error adding event:", e);
    }
  };

  const handleRegister = async (eventId: string) => {
    if (!user) {
      alert("يجب تسجيل الدخول للتسجيل في الفعالية");
      return;
    }
    
    try {
      if (registeredEvents.includes(eventId)) {
        // Unregister
        const q = query(collection(db, 'eventRegistrations'), where('userId', '==', user.uid), where('eventId', '==', eventId));
        const snapshot = await getDocs(q);
        snapshot.forEach(async (docSnapshot) => {
          await deleteDoc(doc(db, 'eventRegistrations', docSnapshot.id));
        });
        setRegisteredEvents(prev => prev.filter(id => id !== eventId));
      } else {
        // Register
        await addDoc(collection(db, 'eventRegistrations'), {
          userId: user.uid,
          eventId: eventId,
          registeredAt: serverTimestamp()
        });
        setRegisteredEvents(prev => [...prev, eventId]);
      }
    } catch (e) {
      console.error("Error registering for event:", e);
    }
  };

  return (
    <div dir="rtl" className="min-h-screen bg-gray-50 p-4 md:p-8 font-sans">
      <div className="max-w-4xl mx-auto">
        <button onClick={onBack} className="mb-6 text-gray-500 font-bold flex items-center gap-2 hover:text-primary transition-colors">
          <ArrowRight className="w-5 h-5" /> العودة للرئيسية
        </button>
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl font-black text-primary">الفعاليات العلمية</h2>
          {user && (
            <button 
              onClick={() => setShowAddEvent(!showAddEvent)}
              className="bg-primary text-white px-4 py-2 rounded-full font-bold hover:bg-primary/90 transition-colors"
            >
              {showAddEvent ? 'إلغاء' : 'إضافة فعالية'}
            </button>
          )}
        </div>

        {showAddEvent && (
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 mb-8">
            <h3 className="font-bold text-xl text-primary mb-4">إضافة فعالية جديدة</h3>
            <div className="space-y-4">
              <input type="text" value={title} onChange={e => setTitle(e.target.value)} placeholder="عنوان الفعالية" className="w-full bg-gray-50 rounded-xl py-3 px-4 outline-none focus:ring-2 focus:ring-primary/20 border border-gray-100" />
              <div className="flex gap-4">
                <input type="date" value={date} onChange={e => setDate(e.target.value)} className="w-1/2 bg-gray-50 rounded-xl py-3 px-4 outline-none focus:ring-2 focus:ring-primary/20 border border-gray-100" />
                <input type="text" value={location} onChange={e => setLocation(e.target.value)} placeholder="المكان" className="w-1/2 bg-gray-50 rounded-xl py-3 px-4 outline-none focus:ring-2 focus:ring-primary/20 border border-gray-100" />
              </div>
              <button onClick={handleAddEvent} className="w-full bg-gold text-white py-3 rounded-xl font-bold hover:bg-yellow-500 transition-colors">
                نشر الفعالية
              </button>
            </div>
          </div>
        )}

        <div className="space-y-6">
          {events.length > 0 ? (
            events.map(event => {
              const isRegistered = registeredEvents.includes(event.id);
              return (
                <div key={event.id} className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100">
                  <h3 className="font-bold text-xl text-primary mb-2">{event.title}</h3>
                  <p className="text-gray-500 mb-4">التاريخ: {event.date} | المكان: {event.location}</p>
                  <button 
                    onClick={() => handleRegister(event.id)}
                    className={`px-6 py-2 rounded-full font-bold transition-colors ${isRegistered ? 'bg-gray-200 text-gray-700' : 'bg-primary text-white hover:bg-primary/90'}`}
                  >
                    {isRegistered ? 'إلغاء التسجيل' : 'التسجيل'}
                  </button>
                </div>
              );
            })
          ) : (
            <p className="text-gray-500 text-center py-8">لا توجد فعاليات قادمة حالياً</p>
          )}
        </div>
      </div>
    </div>
  );
}
function AuthorProfilePage({ author, posts, onBack, isFollowing, onFollow, allLikes, onAuthorClick }: { author: any; posts: any[]; onBack: () => void; isFollowing: boolean; onFollow: () => void; allLikes: any[]; onAuthorClick: (author: any) => void }) {
  const [authorDetails, setAuthorDetails] = useState<any>(null);
  const [followersCount, setFollowersCount] = useState(0);
  const [followersList, setFollowersList] = useState<any[]>([]);
  const [followingList, setFollowingList] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState<'posts' | 'followers' | 'following'>('posts');

  useEffect(() => {
    const fetchAuthorData = async () => {
      // Fetch user details
      const usersRef = collection(db, 'users');
      const q = query(usersRef, where('name', '==', author.name));
      const snapshot = await getDocs(q);
      let authorUid = '';
      if (!snapshot.empty) {
        const data = snapshot.docs[0].data();
        setAuthorDetails(data);
        authorUid = snapshot.docs[0].id;
      }
      
      // Fetch followers
      const followsRef = collection(db, 'follows');
      const followersQuery = query(followsRef, where('authorName', '==', author.name));
      const followersSnapshot = await getDocs(followersQuery);
      setFollowersCount(followersSnapshot.size);
      
      const followerIds = followersSnapshot.docs.map(doc => doc.data().followerId);
      if (followerIds.length > 0) {
        // Fetch details for followers (limit to 30 for safety)
        const followerUsersQuery = query(usersRef, where('__name__', 'in', followerIds.slice(0, 30)));
        const followerUsersSnapshot = await getDocs(followerUsersQuery);
        setFollowersList(followerUsersSnapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        })));
      } else {
        setFollowersList([]);
      }

      // Fetch following list
      if (authorUid) {
        const followingQuery = query(followsRef, where('followerId', '==', authorUid));
        const followingSnapshot = await getDocs(followingQuery);
        const followingNames = followingSnapshot.docs.map(doc => doc.data().authorName);
        
        // Fetch details for each followed author
        if (followingNames.length > 0) {
          const followedUsersQuery = query(usersRef, where('name', 'in', followingNames));
          const followedUsersSnapshot = await getDocs(followedUsersQuery);
          setFollowingList(followedUsersSnapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
          })));
        } else {
          setFollowingList([]);
        }
      }
    };
    fetchAuthorData();
  }, [author.name]);

  const authorPostIds = posts.map(p => p.id);
  const totalAtoms = allLikes.filter(like => authorPostIds.includes(like.postId)).length;

  return (
    <div dir="rtl" className="min-h-screen bg-gray-50 p-4 md:p-8 font-sans">
      <div className="max-w-6xl mx-auto">
        <button onClick={onBack} className="mb-6 text-gray-500 font-bold flex items-center gap-2 hover:text-primary transition-colors">
          <ArrowRight className="w-5 h-5" /> العودة للرئيسية
        </button>
        
        {/* Profile Header */}
        <div className="bg-white p-8 md:p-10 rounded-3xl shadow-sm border border-gray-100 mb-8 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-r from-primary/10 to-primary/5"></div>
          <div className="relative flex flex-col md:flex-row items-start md:items-center gap-8 mt-12">
            <div className="w-32 h-32 rounded-full bg-white p-2 shadow-xl flex-shrink-0 z-10">
              {authorDetails?.photoURL ? (
                <img src={authorDetails.photoURL} alt={author.name} className="w-full h-full rounded-full object-cover" referrerPolicy="no-referrer" />
              ) : (
                <div className="w-full h-full rounded-full bg-primary flex items-center justify-center text-white font-black text-5xl">
                  {author.name.split(' ').map((n: string) => n[0]).join('').substring(0, 2)}
                </div>
              )}
            </div>
            
            <div className="flex-1 w-full">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
                <div>
                  <h2 className="text-4xl font-black text-gray-900 mb-2">{author.name}</h2>
                  {authorDetails?.bio && (
                    <p className="text-gray-600 text-lg max-w-2xl leading-relaxed">{authorDetails.bio}</p>
                  )}
                </div>
                <button 
                  onClick={onFollow}
                  className={`px-8 py-3 rounded-full font-bold transition-all shadow-sm ${isFollowing ? 'bg-gray-100 text-gray-700 hover:bg-gray-200' : 'bg-primary text-white hover:bg-primary/90 hover:shadow-md'}`}
                >
                  {isFollowing ? 'إلغاء المتابعة' : 'متابعة'}
                </button>
              </div>
              
              <div className="flex items-center gap-8 mt-6 pt-6 border-t border-gray-100">
                <div 
                  className={`flex items-center gap-2 cursor-pointer transition-colors ${activeTab === 'followers' ? 'text-primary' : 'text-gray-700 hover:text-primary'}`} 
                  title="المتابعون"
                  onClick={() => setActiveTab('followers')}
                >
                  <Users className="w-6 h-6 text-blue-500" />
                  <p className="text-2xl font-black">{followersCount}</p>
                </div>
                <div 
                  className={`flex items-center gap-2 cursor-pointer transition-colors ${activeTab === 'following' ? 'text-primary' : 'text-gray-700 hover:text-primary'}`} 
                  title="يتابع"
                  onClick={() => setActiveTab('following')}
                >
                  <UserPlus className="w-6 h-6 text-purple-500" />
                  <p className="text-2xl font-black">{followingList.length}</p>
                </div>
                <div className="flex items-center gap-2 text-gray-700" title="الذرات (الإعجابات)">
                  <Atom className="w-6 h-6 text-gold" />
                  <p className="text-2xl font-black">{totalAtoms}</p>
                </div>
                <div 
                  className={`flex items-center gap-2 cursor-pointer transition-colors ${activeTab === 'posts' ? 'text-primary' : 'text-gray-700 hover:text-primary'}`} 
                  title="الأبحاث المنشورة"
                  onClick={() => setActiveTab('posts')}
                >
                  <BookOpen className="w-6 h-6 text-primary" />
                  <p className="text-2xl font-black">{posts.length}</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="mb-8 flex items-center gap-4 bg-white p-2 rounded-2xl shadow-sm border border-gray-100 w-fit">
          <button 
            onClick={() => setActiveTab('posts')}
            className={`px-6 py-2 rounded-xl font-bold transition-all ${activeTab === 'posts' ? 'bg-primary text-white shadow-md' : 'text-gray-500 hover:bg-gray-50'}`}
          >
            الأبحاث ({posts.length})
          </button>
          <button 
            onClick={() => setActiveTab('followers')}
            className={`px-6 py-2 rounded-xl font-bold transition-all ${activeTab === 'followers' ? 'bg-primary text-white shadow-md' : 'text-gray-500 hover:bg-gray-50'}`}
          >
            المتابعون ({followersCount})
          </button>
          <button 
            onClick={() => setActiveTab('following')}
            className={`px-6 py-2 rounded-xl font-bold transition-all ${activeTab === 'following' ? 'bg-primary text-white shadow-md' : 'text-gray-500 hover:bg-gray-50'}`}
          >
            يتابع ({followingList.length})
          </button>
        </div>

        <div className="grid grid-cols-1 gap-8">
          {activeTab === 'posts' && (
            <div>
              <h3 className="text-2xl font-black text-gray-900 mb-6 flex items-center gap-3">
                <BookOpen className="w-6 h-6 text-primary" />
                الأبحاث المنشورة
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {posts.map((post: any) => {
                  const postAtoms = allLikes.filter(like => like.postId === post.id).length;
                  return (
                    <div key={post.id} className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm hover:shadow-lg transition-all duration-300 flex flex-col h-full group">
                      <div className="flex-1">
                        <h4 className="font-black text-xl text-gray-900 mb-3 line-clamp-2 group-hover:text-primary transition-colors">{post.content.split('\n')[0]}</h4>
                        {post.content.split('\n').length > 1 && (
                          <p className="text-gray-600 leading-relaxed line-clamp-3 mb-4 text-sm">{post.content.split('\n').slice(1).join('\n')}</p>
                        )}
                      </div>
                      <div className="pt-4 border-t border-gray-50 flex items-center justify-between mt-auto">
                        <div className="flex items-center gap-2 text-gold">
                          <Atom className="w-5 h-5 fill-gold" />
                          <span className="font-bold font-mono">{postAtoms}</span>
                        </div>
                        <span className="text-xs text-gray-400 font-medium">{post.date}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
              {posts.length === 0 && (
                <div className="text-center py-20 bg-white rounded-3xl border border-gray-100">
                  <Atom className="w-16 h-16 text-gray-200 mx-auto mb-4" />
                  <p className="text-xl text-gray-500 font-bold">لم يقم بنشر أي أبحاث بعد</p>
                </div>
              )}
            </div>
          )}

          {activeTab === 'followers' && (
            <div>
              <h3 className="text-2xl font-black text-gray-900 mb-6 flex items-center gap-3">
                <Users className="w-6 h-6 text-primary" />
                المتابعون
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {followersList.length === 0 ? (
                  <div className="col-span-full text-center py-20 bg-white rounded-3xl border border-gray-100">
                    <Users className="w-16 h-16 text-gray-200 mx-auto mb-4" />
                    <p className="text-xl text-gray-500 font-bold">لا يوجد متابعون بعد</p>
                  </div>
                ) : (
                  followersList.map(user => (
                    <div 
                      key={user.id} 
                      onClick={() => onAuthorClick({ name: user.name, id: user.id })}
                      className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm hover:shadow-md transition-all cursor-pointer group flex items-center gap-4"
                    >
                      <div className="w-16 h-16 rounded-full bg-gray-100 flex-shrink-0 overflow-hidden border-2 border-transparent group-hover:border-primary transition-all">
                        {user.photoURL ? (
                          <img src={user.photoURL} alt={user.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                        ) : (
                          <div className="w-full h-full bg-primary flex items-center justify-center text-white font-black text-2xl">
                            {user.name?.split(' ').map((n: string) => n[0]).join('').substring(0, 2)}
                          </div>
                        )}
                      </div>
                      <div className="flex-1">
                        <p className="font-black text-gray-900 text-lg group-hover:text-primary transition-colors">{user.name}</p>
                        <p className="text-sm text-gray-500 line-clamp-1">{user.bio || 'باحث في بوابة اليمن العلمية'}</p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {activeTab === 'following' && (
            <div>
              <h3 className="text-2xl font-black text-gray-900 mb-6 flex items-center gap-3">
                <UserPlus className="w-6 h-6 text-primary" />
                يتابع
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {followingList.length === 0 ? (
                  <div className="col-span-full text-center py-20 bg-white rounded-3xl border border-gray-100">
                    <UserPlus className="w-16 h-16 text-gray-200 mx-auto mb-4" />
                    <p className="text-xl text-gray-500 font-bold">لا يتابع أحداً بعد</p>
                  </div>
                ) : (
                  followingList.map(user => (
                    <div 
                      key={user.id} 
                      onClick={() => onAuthorClick({ name: user.name, id: user.id })}
                      className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm hover:shadow-md transition-all cursor-pointer group flex items-center gap-4"
                    >
                      <div className="w-16 h-16 rounded-full bg-gray-100 flex-shrink-0 overflow-hidden border-2 border-transparent group-hover:border-primary transition-all">
                        {user.photoURL ? (
                          <img src={user.photoURL} alt={user.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                        ) : (
                          <div className="w-full h-full bg-primary flex items-center justify-center text-white font-black text-2xl">
                            {user.name?.split(' ').map((n: string) => n[0]).join('').substring(0, 2)}
                          </div>
                        )}
                      </div>
                      <div className="flex-1">
                        <p className="font-black text-gray-900 text-lg group-hover:text-primary transition-colors">{user.name}</p>
                        <p className="text-sm text-gray-500 line-clamp-1">{user.bio || 'باحث في بوابة اليمن العلمية'}</p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

import { Settings } from 'lucide-react';

function ProfilePage({ user, posts, onBack, onPublish, onUpdateProfile, onUpdatePhoto, onLogout }: { user: { uid: string; name: string; email: string; bio?: string; atoms: number; badges: string[]; visibility?: string; photoURL?: string }; posts: any[]; onBack: () => void; onPublish: (content: string, title: string, category: string, status: 'draft' | 'published') => void; onUpdateProfile: (name: string, bio: string, visibility: string) => Promise<void>; onUpdatePhoto: (file: File) => Promise<void>; onLogout: () => void }) {
  const [activeTab, setActiveTab] = useState<'posts' | 'activity'>('posts');
  const [showSettings, setShowSettings] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('');
  const [content, setContent] = useState('');
  
  const [editName, setEditName] = useState(user.name);
  const [editBio, setEditBio] = useState(user.bio || '');
  const [editVisibility, setEditVisibility] = useState(user.visibility || 'public');
  const [isSavingProfile, setIsSavingProfile] = useState(false);
  const [isUploadingPhoto, setIsUploadingPhoto] = useState(false);
  const [recentActivity, setRecentActivity] = useState<any[]>([]);

  const handleFileUpload = async (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setIsUploadingPhoto(true);
      try {
        await onUpdatePhoto(e.target.files[0]);
      } catch (e) {
        console.error(e);
        alert('حدث خطأ أثناء رفع الصورة');
      }
      setIsUploadingPhoto(false);
    }
  };

  useEffect(() => {
    const q = query(collection(db, 'comments'), where('userId', '==', user.uid));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const comments = snapshot.docs.map(doc => ({
        id: doc.id,
        type: 'comment',
        content: doc.data().content,
        date: doc.data().createdAt,
        ...doc.data()
      }));

      const userPosts = posts.map(post => ({
        id: post.id,
        type: 'post',
        content: post.content.split('\n')[0], // Use title as content
        date: post.createdAt || Date.now() // Fallback if no createdAt
      }));

      const combined = [...comments, ...userPosts].sort((a, b) => b.date - a.date).slice(0, 3);
      setRecentActivity(combined);
    });
    return () => unsubscribe();
  }, [user.uid, posts]);

  const handlePublish = (status: 'draft' | 'published') => {
    onPublish(content, title, category, status);
    setIsCreating(false);
    setTitle('');
    setCategory('');
    setContent('');
  };

  const handleSaveProfile = async () => {
    setIsSavingProfile(true);
    try {
      await onUpdateProfile(editName, editBio, editVisibility);
      alert('تم حفظ الملف الشخصي بنجاح');
      setShowSettings(false);
    } catch (e) {
      console.error(e);
      alert('حدث خطأ أثناء حفظ الملف الشخصي');
    }
    setIsSavingProfile(false);
  };

  return (
    <div dir="rtl" className="min-h-screen bg-gray-50 p-4 md:p-8 font-sans">
      <div className="max-w-5xl mx-auto relative">
        <div className="flex justify-between items-center mb-6">
          <button onClick={onBack} className="text-gray-500 font-bold flex items-center gap-2 hover:text-primary transition-colors">
            <ArrowRight className="w-5 h-5" /> العودة للرئيسية
          </button>
          <button onClick={() => setShowSettings(true)} className="text-gray-500 hover:text-primary transition-colors p-2 rounded-full hover:bg-gray-100">
            <Settings className="w-6 h-6" />
          </button>
        </div>
        
        <div className="bg-white p-8 md:p-10 rounded-3xl shadow-lg border border-gray-100 mb-8 bg-gradient-to-br from-primary/5 to-white relative">
          <div className="flex flex-col md:flex-row items-center gap-8">
            <div className="relative">
              <div className="w-32 h-32 rounded-full bg-primary flex items-center justify-center text-white font-black text-5xl shadow-xl shadow-primary/20 flex-shrink-0 overflow-hidden">
                {user.photoURL ? (
                  <img src={user.photoURL} alt={user.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                ) : (
                  user.name.split(' ').map(n => n[0]).join('').substring(0, 2)
                )}
              </div>
            </div>
            
            <div className="text-center md:text-right flex-1">
              <h2 className="text-4xl font-black text-primary mb-2">{user.name}</h2>
              <p className="text-gray-500 mb-2">{user.email}</p>
              {user.bio && <p className="text-gray-700 mb-4 max-w-2xl">{user.bio}</p>}
              <div className="flex flex-wrap gap-3 justify-center md:justify-start mt-4">
                <div className="inline-flex items-center gap-2 bg-gold/10 text-gold px-4 py-2 rounded-full font-bold">
                  <Atom className="w-5 h-5" />
                  {user.atoms} ذرة علمية
                </div>
                {user.badges.map(badge => {
                  const config = BADGE_CONFIG[badge] || { icon: Award, color: 'text-primary', bg: 'bg-primary/10' };
                  const Icon = config.icon;
                  return (
                    <div key={badge} className={`inline-flex items-center gap-2 px-4 py-2 rounded-full font-bold text-sm ${config.bg} ${config.color}`}>
                      <Icon className="w-4 h-4" />
                      {badge}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* Tabs Navigation */}
        <div className="flex gap-4 mb-8 border-b border-gray-200">
          <button 
            onClick={() => setActiveTab('posts')}
            className={`pb-4 px-4 font-bold text-lg transition-colors border-b-4 ${activeTab === 'posts' ? 'border-primary text-primary' : 'border-transparent text-gray-400 hover:text-gray-600'}`}
          >
            أبحاثي
          </button>
          <button 
            onClick={() => setActiveTab('activity')}
            className={`pb-4 px-4 font-bold text-lg transition-colors border-b-4 ${activeTab === 'activity' ? 'border-primary text-primary' : 'border-transparent text-gray-400 hover:text-gray-600'}`}
          >
            النشاط الأخير
          </button>
        </div>

        {/* Tab Content */}
        <div className="min-h-[400px]">
          {activeTab === 'posts' && (
            <div className="space-y-8">
              <div className="flex justify-between items-center">
                <h3 className="text-2xl font-black text-primary">أبحاثي المنشورة</h3>
                <button onClick={() => setIsCreating(!isCreating)} className="bg-primary text-white px-6 py-3 rounded-full font-bold hover:bg-primary/90 shadow-md shadow-primary/20 whitespace-nowrap">
                  {isCreating ? 'إلغاء' : 'بحث جديد +'}
                </button>
              </div>

              {isCreating && (
                <div className="bg-white p-8 rounded-3xl shadow-lg border border-gray-100">
                  <h3 className="text-2xl font-black text-primary mb-6">إنشاء بحث جديد</h3>
                  <div className="space-y-6">
                    <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="عنوان البحث..." className="w-full bg-gray-50 rounded-2xl py-3 px-6 border border-gray-200" />
                    <select value={category} onChange={(e) => setCategory(e.target.value)} className="w-full bg-gray-50 rounded-2xl py-3 px-6 border border-gray-200">
                      <option value="">اختر التصنيف</option>
                      <option value="طاقة متجددة">طاقة متجددة</option>
                      <option value="زراعة">زراعة</option>
                      <option value="طب وصحة">طب وصحة</option>
                      <option value="تكنولوجيا">تكنولوجيا</option>
                      <option value="بيئة ومناخ">بيئة ومناخ</option>
                      <option value="أخرى">أخرى</option>
                    </select>
                    <textarea value={content} onChange={(e) => setContent(e.target.value)} placeholder="محتوى البحث..." className="w-full bg-gray-50 rounded-2xl py-4 px-6 border border-gray-200 h-40" />
                    <div className="flex gap-4">
                      <button onClick={() => handlePublish('draft')} className="flex-1 bg-gray-100 text-gray-600 py-3 rounded-2xl font-bold">حفظ كمسودة</button>
                      <button onClick={() => handlePublish('published')} className="flex-1 bg-primary text-white py-3 rounded-2xl font-bold">نشر</button>
                    </div>
                  </div>
                </div>
              )}

              <div className="space-y-6">
                {posts.length > 0 ? (
                  posts.map(post => (
                    <div key={post.id} className="p-6 rounded-3xl bg-white border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
                      <h4 className="font-black text-xl text-gray-900 mb-3">{post.content.split('\n')[0]}</h4>
                      {post.content.split('\n').length > 1 && (
                        <p className="text-gray-700 leading-relaxed whitespace-pre-wrap mb-4">{post.content.split('\n').slice(1).join('\n')}</p>
                      )}
                      <div className="flex items-center justify-between">
                        <span className={`text-xs font-bold px-3 py-1 rounded-full ${post.status === 'published' ? 'text-gold bg-gold/10' : 'text-gray-500 bg-gray-100'}`}>
                          {post.status === 'published' ? 'منشور' : 'مسودة'}
                        </span>
                        <button className="text-primary font-bold text-sm hover:underline">تعديل</button>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-12 bg-white rounded-3xl border border-gray-100">
                    <p className="text-gray-500 font-bold">لم تقم بنشر أي أبحاث بعد</p>
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === 'activity' && (
            <div className="space-y-4 max-w-3xl mx-auto">
              {recentActivity.length > 0 ? (
                recentActivity.map(activity => (
                  <div key={activity.id} className="p-6 rounded-3xl bg-white border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
                    <div className="flex items-center gap-3 mb-3">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${activity.type === 'post' ? 'bg-primary/10' : 'bg-gold/10'}`}>
                        {activity.type === 'post' ? (
                          <PenTool className="w-5 h-5 text-primary" />
                        ) : (
                          <MessageCircle className="w-5 h-5 text-gold" />
                        )}
                      </div>
                      <span className="text-sm font-bold text-gray-600">
                        {activity.type === 'post' ? 'نشرت بحثاً جديداً' : 'علقت على بحث'}
                      </span>
                    </div>
                    <p className="text-base text-gray-800 font-medium mr-12 bg-gray-50 p-4 rounded-2xl">{activity.content}</p>
                    {activity.date && typeof activity.date === 'number' && (
                      <p className="text-xs text-gray-400 mt-3 mr-12">
                        {new Date(activity.date).toLocaleDateString('ar-SA')}
                      </p>
                    )}
                  </div>
                ))
              ) : (
                <div className="p-12 rounded-3xl bg-white border border-gray-100 shadow-sm text-center">
                  <p className="text-gray-500 font-bold">لا توجد تفاعلات حديثة</p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Settings Modal */}
      {showSettings && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-8 max-w-2xl w-full shadow-xl max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-8">
              <h3 className="text-2xl font-black text-primary">الإعدادات</h3>
              <button onClick={() => setShowSettings(false)} className="text-gray-400 hover:text-gray-600">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
              </button>
            </div>
            
            <div className="space-y-6">
              <div className="flex flex-col items-center mb-6">
                <div className="relative mb-4">
                  <div className="w-24 h-24 rounded-full bg-primary flex items-center justify-center text-white font-black text-3xl shadow-lg overflow-hidden">
                    {user.photoURL ? (
                      <img src={user.photoURL} alt={user.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    ) : (
                      user.name.split(' ').map(n => n[0]).join('').substring(0, 2)
                    )}
                  </div>
                  <label className="absolute bottom-0 right-0 bg-white p-2 rounded-full shadow-md cursor-pointer hover:bg-gray-100 border border-gray-100">
                    <input type="file" accept="image/*" className="hidden" onChange={handleFileUpload} disabled={isUploadingPhoto} />
                    <Camera className="w-4 h-4 text-primary" />
                  </label>
                </div>
                {isUploadingPhoto && <p className="text-sm text-primary font-bold">جاري رفع الصورة...</p>}
              </div>

              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">الاسم الكامل</label>
                <input 
                  type="text" 
                  value={editName} 
                  onChange={(e) => setEditName(e.target.value)} 
                  className="w-full bg-gray-50 rounded-xl py-3 px-4 border border-gray-200 focus:ring-2 focus:ring-primary/20 outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">نبذة عني</label>
                <textarea 
                  value={editBio} 
                  onChange={(e) => setEditBio(e.target.value)} 
                  placeholder="اكتب نبذة قصيرة عنك وعن اهتماماتك البحثية..."
                  className="w-full bg-gray-50 rounded-xl py-3 px-4 border border-gray-200 focus:ring-2 focus:ring-primary/20 outline-none h-32 resize-none"
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">خصوصية الملف الشخصي</label>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <button
                    onClick={() => setEditVisibility('public')}
                    className={`py-3 px-4 rounded-xl border font-bold text-sm transition-all ${editVisibility === 'public' ? 'bg-primary/10 border-primary text-primary' : 'bg-gray-50 border-gray-200 text-gray-600 hover:bg-gray-100'}`}
                  >
                    عام
                  </button>
                  <button
                    onClick={() => setEditVisibility('followers')}
                    className={`py-3 px-4 rounded-xl border font-bold text-sm transition-all ${editVisibility === 'followers' ? 'bg-primary/10 border-primary text-primary' : 'bg-gray-50 border-gray-200 text-gray-600 hover:bg-gray-100'}`}
                  >
                    للمتابعين فقط
                  </button>
                  <button
                    onClick={() => setEditVisibility('private')}
                    className={`py-3 px-4 rounded-xl border font-bold text-sm transition-all ${editVisibility === 'private' ? 'bg-primary/10 border-primary text-primary' : 'bg-gray-50 border-gray-200 text-gray-600 hover:bg-gray-100'}`}
                  >
                    خاص
                  </button>
                </div>
                <p className="text-xs text-gray-500 mt-2">
                  {editVisibility === 'public' && 'ملفك الشخصي وأبحاثك مرئية للجميع.'}
                  {editVisibility === 'followers' && 'ملفك الشخصي وأبحاثك مرئية لمتابعيك فقط.'}
                  {editVisibility === 'private' && 'ملفك الشخصي وأبحاثك مرئية لك فقط.'}
                </p>
              </div>
              <div className="pt-4 flex gap-4">
                <button 
                  onClick={handleSaveProfile} 
                  disabled={isSavingProfile || !editName.trim()}
                  className="flex-1 bg-primary text-white px-6 py-4 rounded-xl font-bold hover:bg-primary/90 disabled:opacity-50 transition-colors"
                >
                  {isSavingProfile ? 'جاري الحفظ...' : 'حفظ التغييرات'}
                </button>
              </div>
              
              <div className="pt-8 border-t border-gray-100 mt-8">
                <button 
                  onClick={onLogout}
                  className="w-full flex items-center justify-center gap-2 bg-red-50 text-red-600 px-6 py-4 rounded-xl font-bold hover:bg-red-100 transition-colors"
                >
                  <LogOut className="w-5 h-5" />
                  تسجيل الخروج
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function NotificationsPage({ onBack, notifications }: { onBack: () => void, notifications: any[] }) {
  return (
    <div dir="rtl" className="min-h-screen bg-gray-50 p-4 md:p-8 font-sans">
      <div className="max-w-2xl mx-auto">
        <button onClick={onBack} className="mb-6 text-gray-500 font-bold flex items-center gap-2 hover:text-primary transition-colors">
          <ArrowRight className="w-5 h-5" /> العودة للرئيسية
        </button>
        <h2 className="text-3xl font-black text-primary mb-8">التنبيهات</h2>
        <div className="space-y-4">
          {notifications.length > 0 ? (
            notifications.map(notif => (
              <div key={notif.id} className={`p-4 rounded-2xl shadow-sm border ${notif.read ? 'bg-white border-gray-100' : 'bg-primary/5 border-primary/20'}`}>
                <div className="flex items-center gap-3">
                  {notif.type === 'like' && <Atom className="w-5 h-5 text-gold" />}
                  {notif.type === 'comment' && <MessageCircle className="w-5 h-5 text-primary" />}
                  {notif.type === 'share' && <Share2 className="w-5 h-5 text-primary/80" />}
                  {notif.type === 'new_post' && <PenTool className="w-5 h-5 text-blue-500" />}
                  <p className="text-gray-700">
                    <span className="font-bold text-primary">{notif.fromName}</span>{' '}
                    {notif.type === 'like' && 'أعطى ذرة علمية لبحثك'}
                    {notif.type === 'comment' && 'علق على بحثك'}
                    {notif.type === 'share' && 'شارك بحثك'}
                    {notif.type === 'new_post' && 'نشر بحثاً جديداً'}
                  </p>
                </div>
              </div>
            ))
          ) : (
            <p className="text-gray-500 text-center py-8">لا توجد تنبيهات جديدة</p>
          )}
        </div>
      </div>
    </div>
  );
}

function FeedPost({ post, user, setView, setSelectedAuthor, setIsFollowing }: { key?: any, post: any, user: any, setView: any, setSelectedAuthor: any, setIsFollowing: any }) {
  const [showComments, setShowComments] = useState(false);
  const [commentText, setCommentText] = useState('');
  const [commentsList, setCommentsList] = useState<any[]>([]);
  const [likesCount, setLikesCount] = useState(post.atoms || 0);
  const [hasLiked, setHasLiked] = useState(false);
  const [userLikeId, setUserLikeId] = useState<string | null>(null);
  const [sharesCount, setSharesCount] = useState(0);
  const [commentToDelete, setCommentToDelete] = useState<string | null>(null);
  const [isCommentsExpanded, setIsCommentsExpanded] = useState(false);

  useEffect(() => {
    const q = query(collection(db, 'comments'), where('postId', '==', post.id));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetched = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as any[];
      fetched.sort((a, b) => b.createdAt - a.createdAt);
      setCommentsList(fetched);
    });
    return () => unsubscribe();
  }, [post.id]);

  useEffect(() => {
    const q = query(collection(db, 'likes'), where('postId', '==', post.id));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setLikesCount((post.atoms || 0) + snapshot.size);
      
      if (user) {
        const userLikeDoc = snapshot.docs.find(doc => doc.data().userId === user.uid);
        if (userLikeDoc) {
          setHasLiked(true);
          setUserLikeId(userLikeDoc.id);
        } else {
          setHasLiked(false);
          setUserLikeId(null);
        }
      } else {
        setHasLiked(false);
        setUserLikeId(null);
      }
    });
    return () => unsubscribe();
  }, [post.id, user, post.atoms]);

  useEffect(() => {
    const q = query(collection(db, 'shares'), where('postId', '==', post.id));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setSharesCount(snapshot.size);
    });
    return () => unsubscribe();
  }, [post.id]);

  const handleLike = async () => {
    if (!user) { setView('login'); return; }
    try {
      if (hasLiked && userLikeId) {
        await deleteDoc(doc(db, 'likes', userLikeId));
      } else {
        await addDoc(collection(db, 'likes'), { 
          postId: post.id, 
          userId: user.uid,
          createdAt: serverTimestamp()
        });
        if (user.name !== post.author) {
          await addDoc(collection(db, 'notifications'), {
            targetUser: post.authorId || post.author,
            fromName: user.name,
            type: 'like',
            postId: post.id,
            createdAt: serverTimestamp(),
            read: false
          });
        }
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleCommentSubmit = async () => {
    if (!user) { setView('login'); return; }
    if (!commentText.trim()) return;
    try {
      await addDoc(collection(db, 'comments'), {
        postId: post.id,
        userId: user.uid,
        userName: user.name,
        userPhotoURL: user.photoURL || null,
        content: commentText.trim(),
        createdAt: Date.now()
      });
      if (user.name !== post.author) {
        await addDoc(collection(db, 'notifications'), {
          targetUser: post.authorId || post.author,
          fromName: user.name,
          type: 'comment',
          postId: post.id,
          createdAt: serverTimestamp(),
          read: false
        });
      }
      setCommentText('');
    } catch (e) {
      console.error(e);
      alert('حدث خطأ أثناء إضافة التعليق');
    }
  };

  const handleShare = async () => {
    const shareData = {
      title: 'البوابة العلمية',
      text: `اقرأ هذا البحث من ${post.author}:\n${post.content.substring(0, 100)}...`,
      url: `${window.location.origin}/?post=${post.id}`
    };

    try {
      if (navigator.share) {
        await navigator.share(shareData);
      } else {
        await navigator.clipboard.writeText(`${shareData.text}\n${shareData.url}`);
        alert('تم نسخ الرابط بنجاح!');
      }

      // Store analytics in Firestore
      await addDoc(collection(db, 'shares'), {
        postId: post.id,
        userId: user?.uid || 'anonymous',
        createdAt: serverTimestamp()
      });

      if (user && user.name !== post.author) {
        await addDoc(collection(db, 'notifications'), {
          targetUser: post.authorId || post.author,
          fromName: user.name,
          type: 'share',
          postId: post.id,
          createdAt: serverTimestamp(),
          read: false
        });
      }
    } catch (e) {
      console.error('Error sharing:', e);
    }
  };

  const confirmDeleteComment = async () => {
    if (!commentToDelete) return;
    try {
      await deleteDoc(doc(db, 'comments', commentToDelete));
      setCommentToDelete(null);
    } catch (e) {
      console.error('Error deleting comment:', e);
    }
  };

  const handleDeletePost = async () => {
    if (window.confirm('هل أنت متأكد من حذف هذا البحث؟')) {
      try {
        await deleteDoc(doc(db, 'posts', post.id));
      } catch (e) {
        console.error('Error deleting post:', e);
      }
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4, scale: 1.02 }}
      className="bg-white rounded-3xl shadow-sm border border-gray-100 p-6 transition-shadow duration-300 hover:shadow-lg relative"
    >
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <div 
            className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center text-gray-600 font-black text-lg cursor-pointer hover:bg-gray-200 transition-colors overflow-hidden"
            onClick={() => { setSelectedAuthor({ name: post.author }); setView('author-profile'); }}
          >
            {post.authorPhotoURL ? (
              <img src={post.authorPhotoURL} alt={post.author} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
            ) : (
              post.author.split(' ').map((n: string) => n[0]).join('').substring(0, 2)
            )}
          </div>
          <div>
            <p className="font-black text-gray-900 text-base cursor-pointer hover:underline" onClick={() => { setSelectedAuthor({ name: post.author }); setView('author-profile'); }}>{post.author}</p>
            <p className="text-xs text-gray-400">{post.date}</p>
          </div>
        </div>
        {user && (user.uid === post.authorId || user.name === post.author) && (
          <button onClick={handleDeletePost} className="text-gray-400 hover:text-red-500 transition-colors p-2 rounded-full hover:bg-red-50">
            <Trash2 className="w-4 h-4" />
          </button>
        )}
      </div>
      <div className="mb-6">
        <h3 className="text-xl font-black text-gray-900 mb-3 leading-tight">{post.content.split('\n')[0]}</h3>
        {post.content.split('\n').length > 1 && (
          <p className="text-gray-800 leading-relaxed whitespace-pre-wrap">{post.content.split('\n').slice(1).join('\n')}</p>
        )}
      </div>
      <div className="flex gap-6 border-t border-gray-100 pt-4">
        <button 
          onClick={handleLike} 
          className={`flex items-center gap-2 transition-colors ${hasLiked ? 'text-gold' : 'text-gray-500 hover:text-gold'}`}
        >
          <Atom className={`w-5 h-5 ${hasLiked ? 'fill-gold' : ''}`} />
          <span className="font-bold text-sm font-mono">{likesCount}</span>
        </button>
        <button 
          onClick={() => {
            if (!user) { setView('login'); return; }
            setShowComments(!showComments);
          }} 
          className={`flex items-center gap-2 transition-colors ${showComments ? 'text-gray-900' : 'text-gray-500 hover:text-gray-900'}`}
        >
          <MessageCircle className="w-5 h-5" />
          <span className="font-bold text-sm font-mono">{commentsList.length > 0 ? commentsList.length : ''}</span>
        </button>
        <button 
          onClick={handleShare} 
          className="flex items-center gap-2 text-gray-500 hover:text-gray-900 transition-colors"
        >
          <Share2 className="w-5 h-5" />
          <span className="font-bold text-sm font-mono">{sharesCount > 0 ? sharesCount : ''}</span>
        </button>
      </div>

      {showComments && (
        <div className="mt-6 pt-6 border-t border-gray-50">
          <h4 className="font-bold text-primary mb-4 text-sm">التعليقات</h4>
          <div className="flex gap-3 mb-6">
            <div className="w-8 h-8 rounded-full bg-primary/10 flex-shrink-0 flex items-center justify-center text-primary font-bold text-xs">
              {user?.name?.split(' ').map((n: string) => n[0]).join('') || 'م'}
            </div>
            <div className="flex-1 flex gap-2">
              <input 
                type="text" 
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleCommentSubmit()}
                placeholder="أضف تعليقاً..." 
                className="flex-1 bg-gray-50 rounded-full py-2 px-4 text-sm outline-none focus:ring-2 focus:ring-primary/20 border border-gray-100"
              />
              <button 
                onClick={handleCommentSubmit}
                disabled={!commentText.trim()}
                className="bg-primary text-white px-4 py-2 rounded-full text-sm font-bold disabled:opacity-50 hover:bg-primary/90 transition-colors"
              >
                نشر
              </button>
            </div>
          </div>
          <div className="space-y-4">
            {commentsList.length === 0 ? (
              <p className="text-center text-gray-400 text-sm py-4">لا توجد تعليقات بعد. كن أول من يعلق!</p>
            ) : (
              <>
                {(isCommentsExpanded ? commentsList : commentsList.slice(0, 2)).map(comment => (
                  <div key={comment.id} className="flex gap-3">
                    <div className="w-8 h-8 rounded-full bg-gray-200 flex-shrink-0 flex items-center justify-center text-gray-600 font-bold text-xs overflow-hidden">
                      {comment.userPhotoURL ? (
                        <img src={comment.userPhotoURL} alt={comment.userName} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      ) : (
                        comment.userName?.split(' ').map((n: string) => n[0]).join('') || 'م'
                      )}
                    </div>
                    <div className="flex-1 bg-gray-50 rounded-2xl rounded-tr-none p-3 border border-gray-100 group relative">
                      <div className="flex justify-between items-start">
                        <p className="font-bold text-primary text-xs mb-1">{comment.userName}</p>
                        {user?.uid === comment.userId && (
                          <button 
                            onClick={() => setCommentToDelete(comment.id)}
                            className="text-gray-400 hover:text-red-500 transition-colors p-1"
                            title="حذف التعليق"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                      <p className="text-gray-700 text-sm">{comment.content}</p>
                    </div>
                  </div>
                ))}
                {commentsList.length > 2 && (
                  <button 
                    onClick={() => setIsCommentsExpanded(!isCommentsExpanded)}
                    className="text-sm text-gray-500 hover:text-primary font-bold mt-2 w-full text-right"
                  >
                    {isCommentsExpanded ? 'إخفاء التعليقات السابقة' : `عرض كل التعليقات (${commentsList.length})`}
                  </button>
                )}
              </>
            )}
          </div>
        </div>
      )}

      {commentToDelete && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-sm w-full shadow-xl">
            <h3 className="text-xl font-bold text-gray-900 mb-2">حذف التعليق</h3>
            <p className="text-gray-600 mb-6">هل أنت متأكد من رغبتك في حذف هذا التعليق؟ لا يمكن التراجع عن هذا الإجراء.</p>
            <div className="flex gap-3">
              <button 
                onClick={confirmDeleteComment}
                className="flex-1 bg-red-500 text-white py-2 rounded-xl font-bold hover:bg-red-600 transition-colors"
              >
                نعم، احذف
              </button>
              <button 
                onClick={() => setCommentToDelete(null)}
                className="flex-1 bg-gray-100 text-gray-700 py-2 rounded-xl font-bold hover:bg-gray-200 transition-colors"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}
    </motion.div>
  );
}

export default function App() {
  const [view, setView] = useState<'dashboard' | 'login' | 'profile' | 'events' | 'notifications' | 'author-profile'>('dashboard');
  const [selectedAuthor, setSelectedAuthor] = useState<any>(null);
  const [isFollowing, setIsFollowing] = useState(false);
  const [user, setUser] = useState<{ uid: string; name: string; email: string; bio?: string; atoms: number; badges: string[] } | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [totalLikes, setTotalLikes] = useState(0);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
  const [leaderboardFilter, setLeaderboardFilter] = useState<'daily' | 'weekly' | 'monthly'>('weekly');
  const [topResearchFilter, setTopResearchFilter] = useState<'daily' | 'weekly' | 'monthly'>('weekly');
  const [feedCategory, setFeedCategory] = useState<string>('الكل');
  const [unreadCount, setUnreadCount] = useState(0);
  const [visiblePostsCount, setVisiblePostsCount] = useState(5);
  const [posts, setPosts] = useState<any[]>([]);
  const [allLikes, setAllLikes] = useState<any[]>([]);
  const [events, setEvents] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState('الأسبوع');

  useEffect(() => {
    const q = query(collection(db, 'posts'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetchedPosts = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        date: doc.data().createdAt ? new Date(doc.data().createdAt.toMillis()).toLocaleDateString('ar-EG') : 'الآن'
      }));
      setPosts(fetchedPosts);
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    const unsubscribe = onSnapshot(collection(db, 'likes'), (snapshot) => {
      const fetchedLikes = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        createdAt: doc.data().createdAt || serverTimestamp() // fallback if missing
      }));
      setAllLikes(fetchedLikes);
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    const q = query(collection(db, 'events'), orderBy('date', 'asc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetchedEvents = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setEvents(fetchedEvents);
    });
    return () => unsubscribe();
  }, []);


  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        // Fetch user bio and visibility from Firestore if it exists
        let bio = '';
        let visibility = 'public';
        try {
          const userDoc = await getDoc(doc(db, 'users', firebaseUser.uid));
          if (userDoc.exists()) {
            bio = userDoc.data().bio || '';
            visibility = userDoc.data().visibility || 'public';
          }
        } catch (e) {
          console.error('Error fetching user profile:', e);
        }

        setUser({
          uid: firebaseUser.uid,
          name: firebaseUser.displayName || firebaseUser.email?.split('@')[0] || 'مستخدم',
          email: firebaseUser.email || '',
          bio: bio,
          visibility: visibility,
          photoURL: firebaseUser.photoURL || undefined,
          atoms: 1200,
          badges: ['باحث ناشئ']
        });
        if (view === 'login') setView('dashboard');
      } else {
        setUser(null);
      }
      setAuthReady(true);
    });
    return () => unsubscribe();
  }, [view]);

  useEffect(() => {
    if (!user) return;
    const userPosts = posts.filter(p => p.author === user.name);
    const userPostIds = userPosts.map(p => p.id);
    const baseAtoms = userPosts.reduce((sum, p) => sum + (p.atoms || 0), 0);
    
    const unsubscribe = onSnapshot(collection(db, 'likes'), (snapshot) => {
      let realLikes = 0;
      snapshot.forEach(doc => {
        if (userPostIds.includes(doc.data().postId)) {
          realLikes++;
        }
      });
      setTotalLikes(baseAtoms + realLikes);
    });
    return () => unsubscribe();
  }, [user, posts]);

  useEffect(() => {
    if (!user) return;
    const q = query(collection(db, 'notifications'), where('targetUser', 'in', [user.name, user.uid]));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetched = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as any[];
      fetched.sort((a, b) => (b.createdAt?.toMillis?.() || 0) - (a.createdAt?.toMillis?.() || 0));
      setNotifications(fetched);
      setUnreadCount(fetched.filter(n => !n.read).length);
    }, (error) => {
      console.error("Error fetching notifications:", error);
    });
    return () => unsubscribe();
  }, [user]);

  const handleUpdateProfile = async (newName: string, newBio: string, newVisibility: string) => {
    if (!auth.currentUser || !user) return;
    
    // Update Auth Profile (Name)
    if (newName !== user.name) {
      await updateProfile(auth.currentUser, { displayName: newName });
    }
    
    // Update Firestore Profile (Bio and Visibility)
    await setDoc(doc(db, 'users', user.uid), { bio: newBio, visibility: newVisibility }, { merge: true });
    
    // Update local state
    setUser({ ...user, name: newName, bio: newBio, visibility: newVisibility });
  };

  const handleUpdatePhoto = async (file: File) => {
    if (!auth.currentUser || !user) return;
    const storageRef = ref(storage, `profilePictures/${user.uid}`);
    await uploadBytes(storageRef, file);
    const photoURL = await getDownloadURL(storageRef);
    
    // Update Auth Profile
    await updateProfile(auth.currentUser, { photoURL });
    
    // Update Firestore Users Collection
    await setDoc(doc(db, 'users', user.uid), { photoURL }, { merge: true });
    
    // Update all posts by this user to have the new photoURL
    const postsQuery = query(collection(db, 'posts'), where('authorId', '==', user.uid));
    const postsSnapshot = await getDocs(postsQuery);
    postsSnapshot.forEach(async (postDoc) => {
      await setDoc(doc(db, 'posts', postDoc.id), { authorPhotoURL: photoURL }, { merge: true });
    });

    // Update all comments by this user to have the new photoURL
    const commentsQuery = query(collection(db, 'comments'), where('userId', '==', user.uid));
    const commentsSnapshot = await getDocs(commentsQuery);
    commentsSnapshot.forEach(async (commentDoc) => {
      await setDoc(doc(db, 'comments', commentDoc.id), { userPhotoURL: photoURL }, { merge: true });
    });

    setUser({ ...user, photoURL });
  };

  const addPost = async (content: string, title: string, category: string, status: 'draft' | 'published') => {
    if (!user) return;
    
    const newPostData = {
      author: user.name,
      authorId: user.uid,
      authorPhotoURL: user.photoURL || null,
      content: `${title}\n\n${content}`,
      createdAt: serverTimestamp(),
      atoms: 0,
      dailyAtoms: 0,
      weeklyAtoms: 0,
      monthlyAtoms: 0,
      status,
      category
    };

    try {
      const docRef = await addDoc(collection(db, 'posts'), newPostData);
      
      if (status === 'published') {
        const followersQuery = query(collection(db, 'follows'), where('authorName', '==', user.name));
        const followersSnapshot = await getDocs(followersQuery);
        
        for (const docSnapshot of followersSnapshot.docs) {
          const followerId = docSnapshot.data().followerId;
          await addDoc(collection(db, 'notifications'), {
            targetUser: followerId,
            fromName: user.name,
            type: 'new_post',
            postId: docRef.id,
            createdAt: serverTimestamp(),
            read: false
          });
        }
      }
      setView('dashboard');
    } catch (e) {
      console.error('Error adding post: ', e);
      alert('حدث خطأ أثناء نشر البحث');
    }
  };

  const currentUserPosts = posts.filter(p => p.authorId === user?.uid || p.author === user?.name);
  const currentUserAtoms = totalLikes;
  const currentUserBadges = [getBadgeForAtoms(currentUserAtoms)];

  const enrichedUser = user ? { ...user, atoms: currentUserAtoms, badges: currentUserBadges } : null;

  const filteredPosts = posts
    .filter(post => 
      (post.content.toLowerCase().includes(searchQuery.toLowerCase()) || 
      post.author.toLowerCase().includes(searchQuery.toLowerCase())) &&
      (feedCategory === 'الكل' || post.category === feedCategory)
    );

  const getLikesCountForPeriod = (postId: string, period: 'daily' | 'weekly' | 'monthly') => {
    const now = Date.now();
    const periods = {
      daily: 24 * 60 * 60 * 1000,
      weekly: 7 * 24 * 60 * 60 * 1000,
      monthly: 30 * 24 * 60 * 60 * 1000
    };
    return allLikes.filter(like => {
      if (like.postId !== postId) return false;
      const likeTime = like.createdAt?.toMillis?.() || 0;
      return now - likeTime <= periods[period];
    }).length;
  };

  const topPosts = [...posts]
    .map(post => ({
      ...post,
      calculatedAtoms: getLikesCountForPeriod(post.id, topResearchFilter)
    }))
    .sort((a, b) => b.calculatedAtoms - a.calculatedAtoms)
    .slice(0, 3);

  const getAuthorLikesForPeriod = (authorName: string, period: 'daily' | 'weekly' | 'monthly') => {
    const authorPostIds = posts.filter(p => p.author === authorName).map(p => p.id);
    const now = Date.now();
    const periods = {
      daily: 24 * 60 * 60 * 1000,
      weekly: 7 * 24 * 60 * 60 * 1000,
      monthly: 30 * 24 * 60 * 60 * 1000
    };
    return allLikes.filter(like => {
      if (!authorPostIds.includes(like.postId)) return false;
      const likeTime = like.createdAt?.toMillis?.() || 0;
      return now - likeTime <= periods[period];
    }).length;
  };

  const uniqueAuthors = Array.from(new Set(posts.map(p => p.author))) as string[];
  const calculatedResearchers = uniqueAuthors.map((authorName, index) => {
    const authorPosts = posts.filter(p => p.author === authorName);
    const photoURL = authorPosts.find(p => p.authorPhotoURL)?.authorPhotoURL || null;
    // Calculate all-time atoms for badge
    const totalAtoms = allLikes.filter(like => authorPosts.map(p => p.id).includes(like.postId)).length;
    const periodAtoms = getAuthorLikesForPeriod(authorName, leaderboardFilter);
    return {
      id: index,
      name: authorName,
      photoURL,
      atoms: periodAtoms,
      badges: [getBadgeForAtoms(totalAtoms)]
    };
  });

  const filteredResearchers = calculatedResearchers
    .filter(researcher => String(researcher.name).toLowerCase().includes(searchQuery.toLowerCase()))
    .sort((a, b) => b.atoms - a.atoms)
    .slice(0, 5);

  const visiblePosts = filteredPosts.slice(0, visiblePostsCount);

  useEffect(() => {
    const handleScroll = () => {
      if (
        window.innerHeight + document.documentElement.scrollTop >=
        document.documentElement.offsetHeight - 100
      ) {
        setVisiblePostsCount(prev => Math.min(prev + 5, filteredPosts.length));
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [filteredPosts.length]);

  useEffect(() => {
    const checkFollowStatus = async () => {
      if (!user || !selectedAuthor) return;
      const followRef = doc(db, 'follows', `${user.uid}_${selectedAuthor.name}`);
      const followSnap = await getDoc(followRef);
      setIsFollowing(followSnap.exists());
    };
    checkFollowStatus();
  }, [user, selectedAuthor]);

  if (!authReady) return <div className="min-h-screen flex items-center justify-center bg-gray-50"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div></div>;

  if (view === 'login') return <LoginPage onBack={() => setView('dashboard')} />;
  if (view === 'profile') return <ProfilePage user={enrichedUser!} posts={currentUserPosts} onBack={() => setView('dashboard')} onPublish={addPost} onUpdateProfile={handleUpdateProfile} onUpdatePhoto={handleUpdatePhoto} onLogout={() => setShowLogoutConfirm(true)} />;
  const handleFollow = async () => {
    if (!user) { setView('login'); return; }
    const followRef = doc(db, 'follows', `${user.uid}_${selectedAuthor.name}`);
    if (isFollowing) {
      await deleteDoc(followRef);
      setIsFollowing(false);
    } else {
      await setDoc(followRef, { followerId: user.uid, authorName: selectedAuthor.name });
      setIsFollowing(true);
    }
  };

  if (view === 'author-profile') return (
    <AuthorProfilePage 
      author={selectedAuthor} 
      posts={posts.filter(p => p.author === selectedAuthor.name)} 
      onBack={() => setView('dashboard')} 
      isFollowing={isFollowing} 
      onFollow={handleFollow} 
      allLikes={allLikes}
      onAuthorClick={(author) => {
        setSelectedAuthor(author);
        setIsFollowing(false); // Reset following state for new author
      }}
    />
  );
  if (view === 'events') return <EventsPage onBack={() => setView('dashboard')} events={events} user={user} />;
  if (view === 'notifications') {
    // Mark as read when opening
    notifications.forEach(n => {
      if (!n.read) {
        setDoc(doc(db, 'notifications', n.id), { read: true }, { merge: true });
      }
    });
    return <NotificationsPage onBack={() => setView('dashboard')} notifications={notifications} />;
  }

  const tabs = ['اليوم', 'الأسبوع', 'الشهر'];

  return (
    <div dir="rtl" className="min-h-screen bg-gray-50 font-sans text-gray-800 antialiased">
      {/* Top Panel */}
      <header className="bg-white border-b border-gray-100 shadow-[0_2px_10px_rgba(0,0,0,0.02)] sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          
          {/* Right (Start in RTL): Logo */}
          <div className="flex items-center">
            <div className="flex items-center gap-2 cursor-pointer" onClick={() => setView('dashboard')}>
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-gold font-black text-xl shadow-sm">Y</div>
              <h1 className="text-xl font-black text-gray-900 hidden md:block tracking-tight">البوابة العلمية</h1>
            </div>
          </div>

          {/* Center: Sleek Elongated Search Bar */}
          <div className="flex-1 max-w-2xl mx-6">
            <div className="relative group">
              <Search strokeWidth={1.5} className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 group-focus-within:text-primary transition-colors" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="البحث عن أبحاث أو باحثين..."
                className="w-full bg-gray-50/50 hover:bg-gray-50 border border-gray-200 rounded-full py-2.5 pr-11 pl-4 outline-none focus:bg-white focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all text-sm font-medium text-gray-900 placeholder-gray-400"
              />
            </div>
          </div>

          {/* Left (End in RTL): Actions (Notifications, Profile) */}
          <div className="flex items-center gap-3">
            {user ? (
              <>
                <motion.button 
                  key={unreadCount}
                  initial={unreadCount > 0 ? { scale: 1.2, rotate: -15 } : false}
                  animate={{ scale: 1, rotate: 0 }}
                  transition={{ type: "spring", stiffness: 400, damping: 10 }}
                  onClick={() => setView('notifications')} 
                  className="text-gray-500 hover:text-gray-900 transition-all relative p-2.5 rounded-full hover:bg-gray-100"
                >
                  <Bell strokeWidth={1.5} className={`w-5 h-5 ${unreadCount > 0 ? 'text-gray-900' : ''}`} />
                  {unreadCount > 0 && (
                    <motion.span 
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      className="absolute top-1 right-1 min-w-[18px] h-[18px] flex items-center justify-center bg-red-500 text-white text-[10px] font-bold rounded-full border-2 border-white px-1 shadow-sm"
                    >
                      {unreadCount > 99 ? '99+' : unreadCount}
                    </motion.span>
                  )}
                </motion.button>
                
                <button onClick={() => setView('profile')} className="flex items-center gap-2 pl-3 pr-1 py-1 bg-white border border-gray-200 rounded-full shadow-sm hover:border-gray-300 transition-colors">
                  <div className="w-7 h-7 rounded-full bg-gray-100 flex items-center justify-center text-gray-600 font-bold text-xs overflow-hidden">
                    {user.photoURL ? (
                      <img src={user.photoURL} alt={user.name} className="w-full h-full object-cover rounded-full" />
                    ) : (
                      user.name.split(' ').map(n => n[0]).join('')
                    )}
                  </div>
                  <span className="text-sm text-gray-800 font-medium">{user.name.split(' ')[0]}</span>
                </button>
              </>
            ) : (
              <button onClick={() => setView('login')} className="flex items-center gap-2 px-6 py-2 bg-primary text-white rounded-full font-bold hover:bg-primary/90 transition-colors text-sm shadow-sm">
                <LogIn strokeWidth={1.5} className="w-4 h-4" />
                تسجيل دخول
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8 grid grid-cols-1 md:grid-cols-4 gap-8">
        {/* Left Sidebar: Leaderboards */}
        <aside className="md:col-span-1 space-y-6">
          {/* Best Research */}
          <div 
            className="bg-white rounded-3xl shadow-sm border border-gray-100 p-6 overflow-hidden relative"
            style={{
              backgroundImage: `linear-gradient(rgba(255, 255, 255, 0.92), rgba(255, 255, 255, 0.92)), url(${DASHBOARD_IMAGES.TOP_RESEARCH})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center'
            }}
          >
            <div className="absolute top-0 right-0 w-24 h-24 bg-gold/5 rounded-bl-full -mr-4 -mt-4" />
            <div className="bg-primary p-4 rounded-2xl mb-6 relative z-10">
              <h2 className="font-black text-gold text-lg flex items-center gap-2">
                <TrendingUp className="text-gold w-5 h-5" />
                أبرز الأبحاث
              </h2>
            </div>

            <div className="flex bg-gray-100 p-1 rounded-xl mb-6 relative z-10">
              <button 
                onClick={() => setTopResearchFilter('daily')}
                className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all ${topResearchFilter === 'daily' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
              >
                اليوم
              </button>
              <button 
                onClick={() => setTopResearchFilter('weekly')}
                className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all ${topResearchFilter === 'weekly' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
              >
                هذا الأسبوع
              </button>
              <button 
                onClick={() => setTopResearchFilter('monthly')}
                className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all ${topResearchFilter === 'monthly' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
              >
                هذا الشهر
              </button>
            </div>

            <div className="space-y-4 relative z-10">
              {topPosts.map((post) => (
                <div 
                  key={post.id} 
                  className="group p-4 rounded-2xl bg-gray-50 hover:bg-gray-100 transition-all duration-300 cursor-pointer border border-gray-100 hover:border-gray-200"
                  onClick={() => {
                    setSelectedAuthor({ name: post.author });
                    setView('author-profile');
                  }}
                >
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-xs overflow-hidden">
                      {post.authorPhotoURL ? (
                        <img src={post.authorPhotoURL} alt={post.author} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      ) : (
                        post.author.split(' ').map((n: string) => n[0]).join('').substring(0, 2)
                      )}
                    </div>
                    <span className="text-xs font-bold text-gray-600">{post.author}</span>
                  </div>
                  <p className="font-bold text-gray-800 group-hover:text-gray-900 text-sm mb-1 transition-colors line-clamp-2">{post.content.split('\n')[0]}</p>
                  <div className="flex items-center gap-1.5 mt-2">
                    <div className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-gray-200 text-gray-700 group-hover:bg-gray-300 transition-colors">
                      <Atom className="w-3.5 h-3.5 text-primary" />
                      <span className="text-xs font-bold">
                        {post.calculatedAtoms} ذرة علمية
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Best Researchers */}
          <div 
            className="bg-white rounded-3xl shadow-sm border border-gray-100 p-6 relative overflow-hidden"
            style={{
              backgroundImage: `linear-gradient(rgba(255, 255, 255, 0.92), rgba(255, 255, 255, 0.92)), url(${DASHBOARD_IMAGES.ELITE_RESEARCHERS})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center'
            }}
          >
            <div className="absolute bottom-0 left-0 w-24 h-24 bg-gray-100 rounded-tr-full -ml-4 -mb-4" />
            <div className="bg-primary p-4 rounded-2xl mb-6 relative z-10">
              <h2 className="font-black text-gold text-lg flex items-center gap-2">
                <Award className="text-gold w-5 h-5" />
                نخبة الباحثين
              </h2>
            </div>
            
            <div className="flex bg-gray-50 p-1 rounded-lg mb-6">
              <button 
                onClick={() => setLeaderboardFilter('daily')}
                className={`flex-1 py-1.5 text-xs font-bold rounded-md transition-all ${leaderboardFilter === 'daily' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
              >
                اليوم
              </button>
              <button 
                onClick={() => setLeaderboardFilter('weekly')}
                className={`flex-1 py-1.5 text-xs font-bold rounded-md transition-all ${leaderboardFilter === 'weekly' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
              >
                هذا الأسبوع
              </button>
              <button 
                onClick={() => setLeaderboardFilter('monthly')}
                className={`flex-1 py-1.5 text-xs font-bold rounded-md transition-all ${leaderboardFilter === 'monthly' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
              >
                هذا الشهر
              </button>
            </div>

            <div className="space-y-4 relative z-10">
              {filteredResearchers.length > 0 ? (
                filteredResearchers.map((researcher, index) => (
                  <div 
                    key={researcher.id} 
                    className="flex items-center gap-3 p-3 rounded-xl hover:bg-gray-50 transition-colors border border-transparent hover:border-gray-100 cursor-pointer group"
                    onClick={() => {
                      setSelectedAuthor({ name: researcher.name });
                      setView('author-profile');
                    }}
                  >
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs flex-shrink-0 ${index === 0 ? 'bg-gold text-white' : index === 1 ? 'bg-gray-200 text-gray-700' : index === 2 ? 'bg-amber-100 text-amber-800' : 'bg-gray-100 text-gray-500'}`}>
                      {index + 1}
                    </div>
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-xs flex-shrink-0 overflow-hidden">
                      {researcher.photoURL ? (
                        <img src={researcher.photoURL} alt={researcher.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      ) : (
                        researcher.name.split(' ').map((n: string) => n[0]).join('').substring(0, 2)
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-gray-800 text-sm group-hover:text-primary transition-colors truncate" title={researcher.name}>{researcher.name}</p>
                      <div className="flex items-center gap-1.5 mt-1.5">
                        <div className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-gray-100 text-gray-700 group-hover:bg-gray-200 transition-colors">
                          <Atom className="w-3 h-3 text-primary" />
                          <span className="text-xs font-bold">{researcher.atoms} ذرة علمية</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-sm text-gray-400 text-center py-4">لا يوجد باحثين مطابقين</p>
              )}
            </div>
          </div>
        </aside>

        {/* Center Feed */}
        <section className="md:col-span-3 space-y-6">
          {/* Main Banner */}
          <div 
            className="h-48 rounded-3xl overflow-hidden relative flex items-center justify-center text-center p-8 shadow-sm border border-gray-100"
            style={{
              backgroundImage: `linear-gradient(rgba(13, 59, 54, 0.7), rgba(13, 59, 54, 0.7)), url(${DASHBOARD_IMAGES.MAIN_BANNER})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center'
            }}
          >
            <div className="relative z-10">
              <h2 className="text-3xl md:text-4xl font-black text-white mb-3 tracking-tight">مستقبل البحث العلمي في اليمن</h2>
              <p className="text-gold font-bold text-lg">اكتشف، شارك، وساهم في بناء المعرفة</p>
            </div>
          </div>

          {/* Category Filter */}
          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
            {['الكل', 'طاقة متجددة', 'زراعة', 'طب وصحة', 'تكنولوجيا', 'بيئة ومناخ', 'أخرى'].map((cat) => (
              <button
                key={cat}
                onClick={() => setFeedCategory(cat)}
                className={`whitespace-nowrap px-4 py-2 rounded-full text-sm font-bold transition-all ${
                  feedCategory === cat 
                    ? 'bg-primary text-white shadow-md' 
                    : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {visiblePosts.length > 0 ? (
            <>
              {visiblePosts.map(post => (
                <FeedPost key={post.id} post={post} user={user} setView={setView} setSelectedAuthor={setSelectedAuthor} setIsFollowing={setIsFollowing} />
              ))}
              {visiblePostsCount < filteredPosts.length && (
                <div className="py-4 flex justify-center">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                </div>
              )}
            </>
          ) : (
            <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-12 text-center">
              <p className="text-gray-500 font-bold">لا توجد أبحاث مطابقة لبحثك</p>
            </div>
          )}
        </section>
      </main>

      {showLogoutConfirm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-sm w-full shadow-xl">
            <h3 className="text-xl font-bold text-gray-900 mb-2">تسجيل الخروج</h3>
            <p className="text-gray-600 mb-6">هل أنت متأكد من رغبتك في تسجيل الخروج من حسابك؟</p>
            <div className="flex gap-3">
              <button 
                onClick={() => {
                  signOut(auth);
                  setShowLogoutConfirm(false);
                }}
                className="flex-1 bg-red-500 text-white py-2 rounded-xl font-bold hover:bg-red-600 transition-colors"
              >
                نعم، خروج
              </button>
              <button 
                onClick={() => setShowLogoutConfirm(false)}
                className="flex-1 bg-gray-100 text-gray-700 py-2 rounded-xl font-bold hover:bg-gray-200 transition-colors"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
